import { calcularIMC, classificarIMC } from '../js/teste.js';
import { expect } from 'chai';

describe('Testes para a Calculadora IMC', () => {

    it('Deve calcular o IMC corretamente', () => {
        const peso = 70;
        const altura = 1.75;

        const imc = calcularIMC(peso, altura);
        expect(imc).to.be.closeTo(22.9, 0.1);
    });

    it('Deve classificar o IMC corretamente para masculino', () => {
        const imc = 22.9;
        const sexo = 'M';
        const peso = 70;
        const altura = 1.75;

        const resultado = classificarIMC(imc, sexo, peso, altura);
        expect(resultado.condicao).to.equal('Você está no peso normal.');
    });

    it('Deve classificar o IMC corretamente para feminino', () => {
        const imc = 22.9;
        const sexo = 'F';
        const peso = 60;
        const altura = 1.65;

        const resultado = classificarIMC(imc, sexo, peso, altura);
        expect(resultado.condicao).to.equal('Você está no peso normal.');
    });
});
