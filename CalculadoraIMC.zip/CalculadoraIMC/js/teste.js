
export function calcularIMC(peso, altura) {
    if (isNaN(peso) || isNaN(altura)) {
        alert('Peso e altura devem ser números válidos');
    }
    return peso / (altura * altura);
}

export function classificarIMC(imc, sexo, peso, altura) {
    let pesoNormal = altura * altura * 25.0;
    let falta = 0;
    let condicao = '';

    if (sexo === 'M') {
        if (imc < 20.7) {
            condicao = 'Você está abaixo do peso.';
            falta = pesoNormal - peso;
        } else if (imc >= 20.7 && imc <= 26.4) {
            condicao = 'Você está no peso normal.';
        } else if (imc >= 26.4 && imc <= 27.8) {
            condicao = 'Um pouco acima do peso.';
            falta = peso - pesoNormal;
        } else if (imc >= 27.8 && imc <= 31.1) {
            condicao = 'Acima do peso.';
            falta = peso - pesoNormal;
        } else {
            condicao = 'Você está obeso.';
            falta = peso - pesoNormal;
        }
    } else if (sexo === 'F') {
        if (imc < 19.1) {
            condicao = 'Você está abaixo do peso.';
            falta = pesoNormal - peso;
        } else if (imc >= 19.1 && imc <= 25.8) {
            condicao = 'Você está no peso normal.';
        } else if (imc >= 25.8 && imc <= 27.3) {
            condicao = 'Um pouco acima do peso.';
            falta = peso - pesoNormal;
        } else if (imc >= 27.3 && imc <= 32.3) {
            condicao = 'Acima do peso.';
            falta = peso - pesoNormal;
        } else {
            condicao = 'Você está obesa.';
            falta = peso - pesoNormal;
        }
    }

    return { condicao, falta: falta.toFixed(1) };
}
